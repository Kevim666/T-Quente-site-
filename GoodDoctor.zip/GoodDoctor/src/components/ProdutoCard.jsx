
export default function ProdutoCard({ nome, preco }) {
  return (
    <div className="border p-4 rounded shadow hover:shadow-lg">
      <h2 className="text-lg font-semibold">{nome}</h2>
      <p className="text-red-600 font-bold">R$ {preco.toFixed(2)}</p>
      <button className="mt-2 bg-red-500 text-white px-3 py-1 rounded">Adicionar</button>
    </div>
  );
}
