
export default function Home() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Bem-vindo ao TáQuente!</h2>
      <p>Escolha suas refeições favoritas e receba em casa.</p>
    </div>
  );
}
