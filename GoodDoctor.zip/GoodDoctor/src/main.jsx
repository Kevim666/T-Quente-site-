import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'

function App() {
  return <h1>TáQuente está no ar!</h1>
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)