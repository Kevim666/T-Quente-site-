
import ProdutoCard from "../components/ProdutoCard";

export default function Cardapio() {
  const produtos = [
    { nome: "Pizza Calabresa", preco: 35.90 },
    { nome: "Lasanha Bolonhesa", preco: 29.90 },
    { nome: "Refrigerante 2L", preco: 8.00 },
  ];

  return (
    <div className="p-4 grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
      {produtos.map((p, i) => (
        <ProdutoCard key={i} {...p} />
      ))}
    </div>
  );
}
