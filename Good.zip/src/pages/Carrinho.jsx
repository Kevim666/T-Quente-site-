
export default function Carrinho() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Seu carrinho está vazio.</h2>
    </div>
  );
}
