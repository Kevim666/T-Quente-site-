
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="bg-red-600 p-4 text-white flex justify-between items-center">
      <h1 className="text-xl font-bold">TáQuente</h1>
      <div className="space-x-4">
        <Link to="/">Início</Link>
        <Link to="/cardapio">Cardápio</Link>
        <Link to="/carrinho">Carrinho</Link>
      </div>
    </nav>
  );
}
